Author: Harmeet Singh
Last Update Date: 3/15/2025

Chromosome design:
    The idea for the chromosome is to have each index + 1 represent a box. For example, index 0 of a chromosome would be representing box 1.
    Next the actual value would be either a 0 or a 1 to indicate if the box is present in the bag or not. 0 means no box, 1 means box.
    Then we have an array called boxes referenced when we need to know the weight or value of some given box.

Mutation design:
    The mutation function simply will pick a random index from 0 to 11 and then swapping the value to the opposite. Meaning a 0 becomes a 1 and a 1 becomes a 0.

Fitness design:
    The fitness function will take a chromosome and for each box present in the bag will increment a total counter for weight and value based on the boxes values. At the end
    we check if the weight is > 250, if it is give a value of 0 because we do not consider an solution that exceeds 250 weight. Otherwise the fitness value is simply the sum of the boxes' values.

How to use:
    Run the main.py file.

How it works:
    On running the program will create an array(size of population) of empty arrays to store chromosomes and a dictionary to track the fitness value for the current population's chromosomes.
    It will also create 2 arrays for calculating the average fitness values per iteration.
    The program will run createPopulation() which is a function that will create a random chromosome using chromosomeGenerator() which simply randomizes 0's and 1's in an array of size 12. This
    is done until the population is filled.
    Then for each chromosome the fitness value is calculated and stored as well as the fitness values for the current iteration being averaged for the graph later.
    Then using the dict to store fitness values, we sort the population such that the top values are first and the worse values are at the bottom.
    Next starts the actual iterations since now the initial setup is done.
    First, it will cull the population by removing the bottom half of values. This leaves us with a population of 10. Then each chromosome is copied and mutated.
    The same calculations for fitness are done again and the population is sorted again. 
    This will eventually lead to the best values staying consistent. 
    We print the first value in the population since it is the best that we have and we can calculate the fitness value to display as well. I went a little further and display which boxes should be brought.
    To add to that, the final graphPrint() will generate a fitness function graph that shows the average fitness value for through each iteration.

Population size used for testing was 20
Iterations were set to 50