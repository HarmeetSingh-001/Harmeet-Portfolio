import random
import matplotlib.pyplot as plt

# this function is to generate a chromosome from new prior information
def chromosomeGenerator():
    tempArray = [0] * 12

    # for every cell, 50% chance to change it from a 0 to a 1 to create a random chromosome
    for i in range(len(tempArray)):
        if random.randint(0,100) < 50:
            tempArray[i] = 1
    
    return str(tempArray)

# used to create initial population
def createPopulation():
    for i in range(populationSize):
        population[i] = chromosomeGenerator()

# used to calculate the fitness value of a given chromosome
def fitness(chromosome):
    totalWeight = 0
    totalValue = 0

    # check every part of chromosome to see if it is active
    for i in range(len(chromosome)):
        active = chromosome[i]

        # if active, meaning a 1 is there, get the corresponding box weight and value and add to totals
        if active == 1:
            weight, value = boxes[i + 1] 
            totalWeight += weight
            totalValue += value
    
    # 0 if weight above 250 and if not then the value of all boxes is returned
    if totalWeight > 250:
        return 0
    else:
        return totalValue
    
# create a copy of a chromosome and alter it
def mutation(chromosome):
    # pick a random cell to mutate
    mutationCell = random.randint(0,11)
    # clone the chromosome
    offspring = chromosome[:]
    
    # swap the value 
    if offspring[mutationCell] == 0:
        offspring[mutationCell] = 1
    else: 
        offspring[mutationCell] = 0
    
    population.append(str(offspring))

# normal solution print
def solutionPrint():
    bestSolution = eval(population[1])
    print("Harmeet's Suggested Boxes:")
    for i in range(len(bestSolution)):
        if bestSolution[i] == 1:
            print("Bring Box #" + str(i + 1))
    
    print("-------------------------------------------")
    print("Final Chromosome: " + str(bestSolution) + " Final Fitness: " + str(fitness(bestSolution)))

# display of fitness value graph
def graphPrint():
    x = range(len(totalAverageFitness))
    plt.plot(x, totalAverageFitness)
    plt.xlabel("Iteration")
    plt.ylabel("Average Fitness Value")
    plt.title("Average Fitness Function Graph")
    plt.legend()
    plt.show()

# populationSize to always have a consistent size
# population will store all of our canditates
# populationSorting is used to arrange the array based on fitness function to make culling easier
populationSize = 20
population = [[]] * populationSize
populationSorting = {}

# boxes will be our reference for what each part of the chromosome relates to 
# It will also be used for calculations in the fitness function
boxes = {}
boxes[1] = (20,6)
boxes[2] = (30,5)
boxes[3] = (60,8)
boxes[4] = (90,7)
boxes[5] = (50,6)
boxes[6] = (70,9)
boxes[7] = (30,4)
boxes[8] = (30,5)
boxes[9] = (70,4)
boxes[10] = (20,9)
boxes[11] = (20,2)
boxes[12] = (60,1)

currentAverageFitness = []
totalAverageFitness = []

# create initial population
createPopulation()
# create initial fitness mapping
for chromosome in population:
    populationSorting[str(chromosome)] = fitness(eval(chromosome))
    currentAverageFitness.append(fitness(eval(chromosome)))

totalAverageFitness.append(sum(currentAverageFitness)/len(population))
currentAverageFitness.clear()

population = sorted(population, key=lambda x: populationSorting[x], reverse=True)

# run for 100 iterations where we cut population, create new offsprint, calculate fitness, then repeat.
# we also track the average fitness values to display later
for i in range(0,50):
    population = population[:len(population)//2]
    for i in range(len(population)):
        mutation(eval(population[i]))
    
    populationSorting.clear()
    for chromosome in population:
        populationSorting[str(chromosome)] = fitness(eval(chromosome))
        currentAverageFitness.append(fitness(eval(chromosome)))
    
    totalAverageFitness.append(sum(currentAverageFitness)/len(population))
    currentAverageFitness.clear()

    population = sorted(population, key=lambda x: populationSorting[x], reverse=True)

# prints normal solution with what boxes should be brought and the optimal solution
solutionPrint()
# displays a graph of the average fitness values through iterations
graphPrint()

