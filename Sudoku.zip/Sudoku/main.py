import random

# LIFO stack taken from W3 Schools to implement backtracking queue
class Stack:
    def __init__(self):
        self.stack = []
    
    def push(self, element):
        self.stack.append(element)
    
    def pop(self):
        if self.isEmpty():
            return "Stack is empty"
        return self.stack.pop()
    
    def peek(self):
        if self.isEmpty():
            return "Stack is empty"
        return self.stack[-1]
    
    def isEmpty(self):
        return len(self.stack) == 0
    
    def size(self):
        return len(self.stack)
    
    def printStack(self): 
        print(self.stack) 


# update the domain of all remaining empty cells
def updateDomains():
    # clear the domain each time to ensure only the values we care about are added
    domains.clear()
    for i in range(9):
        for j in range(9):
            if board[i][j] == 0:
                # set domain to full and remove all values in the row and col of the current cell
                currentDomain = [1,2,3,4,5,6,7,8,9]
                for x in range (9):
                    if board[i][x] != 0 and board[i][x] in currentDomain:
                        currentDomain.remove(board[i][x])
                    if board[x][j] != 0 and board[x][j] in currentDomain:
                        currentDomain.remove(board[x][j])
                
                # then check which grid the current cell is in and remove additional numbers
                for box in boxes:
                    if (i,j) in box:
                        currentBox = box
                        break
                
                for x,y in currentBox:
                    if board[x][y] != 0 and board[x][y] in currentDomain:
                        currentDomain.remove(board[x][y])


                # add to domains
                domains[(i,j)] = currentDomain

# forward checking
# check all row, col, and grid cells related to the given cell to verify that the current update does not have issues
def checkDomains(row,col):
    for x in range(9):
        if (row,x) in domains:
            if len(domains[(row,x)]) == 0:
                return False
        
        if (x,col) in domains:
            if len(domains[(x,col)]) == 0:
                return False
        
    for box in boxes:
        if (row,col) in box:
            currentBox = box
            break
    for i,j in currentBox:
        if (i,j) in domains:
            if len(domains[(i,j)]) == 0:
                return False
    
    return True

# ask for user input
print("============================================================")
print("Welcome to the Sudoku Puzzle Solver 3000!")
userChoice = input("Enter a '1' for Normal Puzzle, Enter any other value for E̸͔̺̎V̶̟̒I̴̤̙͆L̵̢̘̊  Puzzle: ")
# initilize boards
# 0 represents empty
if userChoice == "1":
    board = [
        [6,0,8,7,0,2,1,0,0],
        [4,0,0,0,1,0,0,0,2],
        [0,2,5,4,0,0,0,0,0],
        [7,0,1,0,8,0,4,0,5],
        [0,8,0,0,0,0,0,7,0],
        [5,0,9,0,6,0,3,0,1],
        [0,0,0,0,0,6,7,5,0],
        [2,0,0,0,9,0,0,0,8],
        [0,0,6,8,0,5,2,0,3]
    ]
else:
    board = [
        [0,7,0,0,4,2,0,0,0],
        [0,0,0,0,0,8,6,1,0],
        [3,9,0,0,0,0,0,0,7],
        [0,0,0,0,0,4,0,0,9],
        [0,0,3,0,0,0,7,0,0],
        [5,0,0,1,0,0,0,0,0],
        [8,0,0,0,0,0,0,7,6],
        [0,5,4,8,0,0,0,0,0],
        [0,0,0,6,1,0,0,5,0]
    ]

# boxes, this a a dictionary to help determine which number is in which smaller 3x3 grid
box1 = [(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
box2 = [(0,3),(0,4),(0,5),(1,3),(1,4),(1,5),(2,3),(2,4),(2,5)]
box3 = [(0,6),(0,7),(0,8),(1,6),(1,7),(1,8),(2,6),(2,7),(2,8)]
box4 = [(3,0),(3,1),(3,2),(4,0),(4,1),(4,2),(5,0),(5,1),(5,2)]
box5 = [(3,3),(3,4),(3,5),(4,3),(4,4),(4,5),(5,3),(5,4),(5,5)]
box6 = [(3,6),(3,7),(3,8),(4,6),(4,7),(4,8),(5,6),(5,7),(5,8)]
box7 = [(6,0),(6,1),(6,2),(7,0),(7,1),(7,2),(8,0),(8,1),(8,2)]
box8 = [(6,3),(6,4),(6,5),(7,3),(7,4),(7,5),(8,3),(8,4),(8,5)]
box9 = [(6,6),(6,7),(6,8),(7,6),(7,7),(7,8),(8,6),(8,7),(8,8)]
boxes = [box1,box2,box3,box4,box5,box6,box7,box8,box9]

# variable to store all domains
domains = {}
# variable to keep track of all already checked values
checkedValues = {}
# track of where we have visited so far
lastVisited = Stack()
# if DONE then we can end 
done = False


while not done:
    # call updateDomains to set the domains of all current empty cells of the chosen puzzle
    updateDomains()
    # if domains is empty, we are done
    if len(domains) < 1:
        done = True
        break

    # get smallest domain key
    smallDomainKey = min(domains, key=lambda i: len(domains[i]))
    # unpack into x and y coords
    x,y = smallDomainKey
    # get the domain listed
    currentDomain = domains[smallDomainKey]
    # track all guess that do not break the domain of any other
    validGuess = []

    for guess in currentDomain:
        # if the key already has checked values
        if smallDomainKey in checkedValues:
            # make sure that we have not already tried this value
            if guess in checkedValues[smallDomainKey]:
                continue
        board[x][y] = guess
        updateDomains()
        if checkDomains(x,y):
            validGuess.append(guess)
    
    # make sure to reset the value and not leave it as a random guess that MAY be false
    # little side note, this one line took me maybe 2 hours to figure out, everything else was fine :(
    board[x][y] = 0
    
    # if no valid guesses
    if len(validGuess) < 1:
        # take the most recent and uncheck the value, aka set to 0
        prev = lastVisited.pop()
        a,b = prev
        board[a][b] = 0
        # then reset the checkValues for the current index since we dont want to assume these all dont work
        if smallDomainKey in checkedValues:
            checkedValues[smallDomainKey] = []
    else:
        # pick a random value from the list of valid guess that respect the domains
        board[x][y] = random.choice(validGuess)
        # update lastVisited to know where to come back to
        lastVisited.push(smallDomainKey)
        # update checkedValues with current guess
        checkedValues.setdefault(smallDomainKey, []).append(board[x][y])
    

# print
print("------------------------------------------------------------")
print("The solution Sudoku Puzzle Solver 3000 found is: ")
for row in board:
    print(" ".join(map(str, row)))
print("============================================================")
