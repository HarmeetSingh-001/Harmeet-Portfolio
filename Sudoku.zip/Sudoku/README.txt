Author: Harmeet Singh
Date Last Updated: 4/1/2025

How to use:
    Download file, open file, run file.
    You will be prompted to enter a value to determine the puzzle. Enter a 1 for the normal puzzle given on the assignment page.
    Enter any other value to use evil puzzle.


Basic Assumptions:
    Puzzle Source:
        There are only 2 Sudoku puzzles avaliable for this solver
        Normal or Evil specified by user input for which will be solved.
        If you want to solve another puzzle, simply replace a given one
    Method of solving:
        To solve this problem, all empty squares will be considered, each will
        be given a domain which is their setup of possible values. This domain will
        be all the possible values minus any that appear in the 3x3 they are in or
        in the row or column of that given square. We will pick the square with the
        smallest domain then check all values to see which are okay to use by checking
        the domain of all affected squares. Then we will add the square to a stack that
        tracks where we have been in what order AND we will add the value given to the 
        square to the square's already checked values. No guess is okay if the guess was
        already checked. In the event we run into a square that is unable to make a guess,
        we will reset that square's checked values and then set the most recent square back
        to empty and try another value. This will repeat until some solution exists. Once we
        have no more empty cells the program terminates and a solution is printed.

Choices Made:
    Variables:
        userChoice: 
            decides which puzzle to solve
        board:
            puzzle to solve
        box1-9:
            each box is a list of pairs that are associated with the 3x3 grids shown in a 
            Sudoku puzzle and will be used to see if some given x,y pair is in the same 3x3
            as another x,y pair
        boxes:
            used to hold all the boxes
        domains:
            a dictionary, key = Sudoku Square in the form (x,y), value = list of possible values
        checkedValues:
            a dictionary, key = Sudoku Square in the form (x,y), value = list of already seen values
        lastVisited:
            stack used to track which square we have lastVisited
        done:
            boolean for checking if the program should terminate

    Functions: The following are methods used to help make code cleaner and easier to debug
        class Stack:
            taken from W3 Schools to implement a stack to be used for tracking the order of
            square visits
        def updateDomains():
            This will take the domains variable, reset it to empty and then for each square in the 
            board, it will update the domain values. It does this by removing any instance of a value from
            the current domain if it appears in the same 3x3 or in the row or column.
        def checkDomains():
            Given some pair, x,y will return True if all row and col and 3x3 "neighbors" still have a domain with
            length of 1 or more. This is used to verify if a guess is valid or not.
        main body:
            asks user for which board to use.

            update domains and then take the smallest domain length key and for that position in the grid, test all
            possible domain values and add them to the list of valid guesses. Then pick one of them at random and 
            update the lastVisited and checkedValues for the square. Repeat. If there is no valid guess, take the most recent
            square and make it empty again and reset the CURRENT square's checked values then repeat.

            print out board, this will be the solution
    
