Author: Harmeet Singh

How to use:
To run the robot, run the main.py file.
Upon running you will see that the robot is online and will then ask you for an input.
The input is simply for the 2 cleaning modes.
Typing 'G' or 'g' will enable General Cleaning where it will check for Dusty Spot, Clean Floor, and then finish.
Typing 'S' or 's' will enable Spot Cleaning where it will clean the current spot for 20 seconds and then ask again what to do.
Typing 'R' or 'r' will pick General or Spot Cleaning at random
Typing 'A' or 'a' will let the robot pick the mode on its own at random however will no longer ask for user input on loops and just run until the end of the "day"
Typing anything else will result in no task given meaning the robot will Do Nothing

Your cleaning mode may not run initially if the battery was less than 30, once it charges back up then it will apply your cleaning mode.

Assumptions:

The tree built in robot_behavior.py is built piece by piece rather than 1 large declaration so that it is easier to see which parts are being connected. I started from the bottom nodes and worked up. Each branch as a name that hopefully resembles that
which is show in the BT image provided

For the Priority composite, I assumed that the order in which it is declared is the priority order. I also removed any instance of running children to ensure it would also start with the first priority and not any running child.

For Battery, 
    I have 2 charge deplete every 5 "seconds".
    When charging the robot gaines 10 charge every "second" and stop once past 95
    I stop the tree from evaluating while the robot is idle in the charging bay since it would not be allowed to do any action anyways using an if statement in front of the evaluation statement.

For Dusty Detection,
    The robot will have a 15% chance to detect dust and once detected it will wait until General Cleaning is applied and then clean that spot out.

For Clean Floor,
    The robot will have a 10% chance to be done cleaning.

For DONE,
    I have it so the robot goes to sleep after 43200 "seconds" to mimic a full 12 hour cycle.


Testing:

There are print statements on almost every part that was implemented aside from the decorators and composites. The rest have the follow format: "'NAME OF TASK/CONDITION' : 'Statement about what it is doing'".
This format is to help easily identify what order events go through.

The values to start with are all false and empty. Battery level is at 29 to ensure that it will full charge itself before beginning the day and letting the user see it happen.
For testing any value can be inserted into the blackboard
    TRUE OR FALSE for all boolean variables
    Any String for the HOME_PATH
    Any int for the battery, no matter the value at some point the values will come down to the range of 28-104 as it will ensure charging less than 30 and will stop after it is past 95.



