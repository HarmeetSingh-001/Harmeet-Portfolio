#
# Behavior Tree framework for A1 Behavior trees assignment.
# CS 131 - Artificial Intelligence
#
# version 3.0.0 - copyright (c) 2023-2024 Santini Fabrizio. All rights reserved.
#

import bt_library as btl
import random

from bt.robot_behavior import robot_behavior
from bt.globals import BATTERY_LEVEL, GENERAL_CLEANING, SPOT_CLEANING, DUSTY_SPOT_SENSOR, HOME_PATH, CHARGING



# Main body of the assignment
current_blackboard = btl.Blackboard()

current_blackboard.set_in_environment(BATTERY_LEVEL, 29)
current_blackboard.set_in_environment(SPOT_CLEANING, False)
current_blackboard.set_in_environment(GENERAL_CLEANING, False)
current_blackboard.set_in_environment(DUSTY_SPOT_SENSOR, False)
current_blackboard.set_in_environment(HOME_PATH, "")
current_blackboard.set_in_environment(CHARGING, False)

elapsedTime = 0
automaticCleaning = False

done = False


# Print the state of the tree nodes before the evaluation
print('BEFORE -------------------------------------------------------------------------')
btl.print_states(current_blackboard)
print('================================================================================')

print("Domestik Drone is Online")

while not done:
    # Each cycle in this while-loop is equivalent to 1 second time

    # Step 1: Change the environment
    #   - Change the battery level (charging or depleting)
    #   - Simulate the response of the dusty spot sensor
    #   - Simulate user input commands
    
    # Battery Simulation
    if current_blackboard.get_in_environment(BATTERY_LEVEL,0) > 95:
        current_blackboard.set_in_environment(CHARGING, False)

    elif current_blackboard.get_in_environment(CHARGING, False):
        current_blackboard.set_in_environment(BATTERY_LEVEL, current_blackboard.get_in_environment(BATTERY_LEVEL,0) + 10)
    
    if elapsedTime % 5 == 0:
        current_blackboard.set_in_environment(BATTERY_LEVEL, current_blackboard.get_in_environment(BATTERY_LEVEL,0) - 2)

    # Dust Detection
    dustChance = random.randint(1,100)
    if dustChance <= 15:
        current_blackboard.set_in_environment(DUSTY_SPOT_SENSOR, True)

    # Cleaning Mode Input
    # Only ask for input if not already cleaning
    if not current_blackboard.get_in_environment(SPOT_CLEANING, False) and not current_blackboard.get_in_environment(GENERAL_CLEANING, False) and not automaticCleaning:
        print('-------------------------------------------------------------------------')
        print("Please Select Cleaning Option: ")
        print("'G' = General Cleaning Mode")
        print("'S' = Spot Cleaning Mode")
        print("'R' = Let Domestik Drone Decide") # reference to a game I play that has roombas
        print("'A' = Automatic Cleaning Mode allows Domestik Drone to run for the rest of the day by itself.")
        cleaningMode = input("Please enter the cleaning mode: ")
        if cleaningMode == "A" or cleaningMode == "a":
            automaticCleaning = True
        if cleaningMode == "G" or cleaningMode == "g":
            current_blackboard.set_in_environment(GENERAL_CLEANING, True)
        elif cleaningMode == "S" or cleaningMode == "s":
            current_blackboard.set_in_environment(SPOT_CLEANING, True)
        elif cleaningMode == "R" or cleaningMode == "r":
            cleaningRandom = random.randint(1,100)
            if  cleaningRandom > 50:
                current_blackboard.set_in_environment(GENERAL_CLEANING, True)
            else:
                current_blackboard.set_in_environment(SPOT_CLEANING, True)
    
    # If automatic cleaning was enabled randomly pick one of the cleaning modes each loop.
    elif automaticCleaning:
        cleaningRandom = random.randint(1,100)
        if  cleaningRandom > 50:
            current_blackboard.set_in_environment(GENERAL_CLEANING, True)
        else:
            current_blackboard.set_in_environment(SPOT_CLEANING, True)

    # Step 2: Evaluating the behavior tree
    # if the robot is currently charging we let it continue charging until the battery reaches above 95
    if not current_blackboard.get_in_environment(CHARGING, False):
        result = robot_behavior.evaluate(current_blackboard)

    # Step 3: Determine if your solution must terminate
    # After a "Full Day" terminate and shut down
    if elapsedTime >= 43200:
        print("All done for today, bye bye!")
        print("Domestik Drone is Offline")
        done = True
    
    # 1 second has passed
    elapsedTime += 1


# Print the state of the tree nodes after the evaluation
print('AFTER --------------------------------------------------------------------------')
btl.print_states(current_blackboard)
print('================================================================================')
    
