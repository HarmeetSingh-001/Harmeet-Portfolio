from bt_library.blackboard import Blackboard
from bt_library.common import ResultEnum
from bt_library.decorator import Decorator
from bt_library.tree_node import TreeNode


class UntilFail(Decorator):
    def __init__(self, child: TreeNode):
        """
        Default constructor.

        :param child: Child associated to the decorator
        """
        super().__init__(child)

    def run(self, blackboard: Blackboard) -> ResultEnum:
        """
        Execute the behavior of the node.

        :param blackboard: Blackboard with the current state of the problem
        :return: The result of the execution
        """

        # if the child fails, return SUCCEEDED
        
        result_child = self.child.run(blackboard)
        if result_child == ResultEnum.FAILED:
            return self.report_succeeded(blackboard)
        else:
            return self.report_running(blackboard)
