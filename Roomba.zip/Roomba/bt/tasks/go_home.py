import bt_library as btl
from ..globals import HOME_PATH


class GoHome(btl.Task):
    """
    Implementation of the Task "Go Home".
    """
    def run(self, blackboard: btl.Blackboard) -> btl.ResultEnum:
        # if somehow HOME_PATH does not have a value, return none
        myWayHome = blackboard.get_in_environment(HOME_PATH, None)
        print("GO HOME: Path to home - " + myWayHome)

        return self.report_succeeded(blackboard)
