import bt_library as btl
import random

class CleanFloor(btl.Task):
    """
    Implementation of the Task "Clean Floor".
    """
    def run(self, blackboard: btl.Blackboard) -> btl.ResultEnum:
        self.print_message('CLEAN FLOOR: Cleaning the floor...')

        doneCleaning = random.randint(1,100)

        # 25% chance to fail (Be done cleaning the floor)
        if doneCleaning <= 10:
            return self.report_failed(blackboard)
        else:
            return self.report_succeeded(blackboard)
