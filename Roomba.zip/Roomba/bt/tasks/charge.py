import bt_library as btl
from ..globals import CHARGING


class Charge(btl.Task):
    """
    Implementation of the Task "Charge".
    """
    def run(self, blackboard: btl.Blackboard) -> btl.ResultEnum:
        self.print_message('CHARGE: Charging')
        blackboard.set_in_environment(CHARGING, True)

        return self.report_succeeded(blackboard)
