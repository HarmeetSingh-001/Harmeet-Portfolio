import bt_library as btl
from ..globals import DUSTY_SPOT_SENSOR


class AlwaysFail(btl.Task):
    """
    Implementation of the Task "Always Fail".

    """
    def run(self, blackboard: btl.Blackboard) -> btl.ResultEnum:
        print("ALWAYS FAIL: Done Dusty Spot Cleaning")
        # Sets DUSTY_SPOT_SENSOR to False since it is only used there
        blackboard.set_in_environment(DUSTY_SPOT_SENSOR, False)
        return self.report_failed(blackboard)
