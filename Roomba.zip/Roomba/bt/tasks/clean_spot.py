import bt_library as btl
from ..globals import SPOT_CLEANING


class CleanSpot(btl.Task):
    """
    Implementation of the Task "Clean Spot".
    """
    def run(self, blackboard: btl.Blackboard) -> btl.ResultEnum:
        self.print_message('CLEAN SPOT: I am cleaning this spot...')
        return self.report_succeeded(blackboard)
