#
# Behavior Tree framework for A1 Behavior trees assignment.
# CS 131 - Artificial Intelligence
#
# version 3.0.0 - copyright (c) 2023-2024 Santini Fabrizio. All rights reserved.
#

import bt as bt
import bt_library as btl

# Instantiate the tree according to the assignment. The following are just examples.

# Example 1:
# tree_root = bt.Timer(5, bt.FindHome())

# Example 2:
# tree_root = bt.Selection(
#     [
#         BatteryLessThan30(),
#         FindHome()
#     ]
# )

# Example 3:
# tree_root = bt.Selection(
#     [
#         bt.BatteryLessThan30(),
#         bt.Timer(10, bt.FindHome())
#     ]
# )

# Battery Sequence
batterySequence = bt.Sequence(
    [
        bt.BatteryLessThan30(),
        bt.FindHome(),
        bt.GoHome(),
        bt.Charge()
    ]
)


# Spot Cleaning Sequence
spotCleaningSequence = bt.Sequence(
    [
        bt.SpotCleaning(),
        bt.Timer(20, bt.CleanSpot()),
        bt.DoneSpot()
    ]
)

# Dusty Spot Sequence
dustySpotSequence = bt.Sequence(
    [
        bt.DustySpot(),
        bt.Timer(35, bt.CleanSpot()),
        bt.AlwaysFail()
    ]
)

# Priority connecting Dusty Spot and Clean Floor
dustyspotPriority = bt.Priority(
    [
        dustySpotSequence,
        bt.UntilFail(bt.CleanFloor())
    ]
)

# Sequence connecting Dusty Spot Priority and Done General
dustySpotDoneGeneralSequence = bt.Sequence(
    [
        dustyspotPriority,
        bt.DoneGeneral()
    ]
)

# Sequence for General Cleaning
generalCleaningSequence = bt.Sequence(
    [
        bt.GeneralCleaning(),
        dustySpotDoneGeneralSequence
    ]
)

# Selection for Cleaning Modes
cleaningModeSelection = bt.Selection(
    [
        spotCleaningSequence,
        generalCleaningSequence
    ]
)

# Root connecting everything and part to start evaluation at
root = bt.Priority(
    [
        batterySequence,
        cleaningModeSelection,
        bt.DoNothing()
    ]
)




# Store the root node in a behavior tree instance
robot_behavior = btl.BehaviorTree(root)
