import heapq
import random
import networkx as nx

def AStar(arr):
    startState = arr[:]
    currentState = arr[:]
    tree.add_node(tuple(currentState), costValue=0, gapValue=gapHeuristic(currentState))
    doneState = False

    while not doneState:
        for i in range(len(currentState) - 1):
            # make a copy of current State and flip it at the current spot to find all possible moves from here
            neighborState = currentState[:]
            neighborState = flip(neighborState, i)

            if neighborState == goalState:
                tree.add_node(tuple(neighborState), costValue=costFunction(currentState), gapValue=gapHeuristic(neighborState))
                tree.add_edge(tuple(currentState), tuple(neighborState))
                doneState = True
                break

            # if the current neighbor is the neighbor we just came from, ignore it and continue
            if tuple(neighborState) in tree.nodes() and tree.has_edge(tuple(neighborState), tuple(currentState)):
                continue

            # removes the node if the priority before is larger than the current since we readd them in afterwards and will only allow the shortest path to exist
            if tuple(neighborState) in tree.nodes() and prioritiyValues[tuple(neighborState)] > tree.nodes[tuple(neighborState)]['gapValue'] + tree.nodes[tuple(neighborState)]['costValue']:
                tree.remove_node(tuple(neighborState))
            
            # if the priority is the same or worse than whatever we have, just ignore it to avoid adding the same node
            elif tuple(neighborState) in tree.nodes() and prioritiyValues[tuple(neighborState)] <= tree.nodes[tuple(neighborState)]['gapValue'] + tree.nodes[tuple(neighborState)]['costValue']:
                continue
            
            # once everything else has passed, we add the current neighbor into the graph with an edge from the current state and add a priority for the neighbor so we know when we should explore it
            tree.add_node(tuple(neighborState), costValue=costFunction(currentState), gapValue=gapHeuristic(neighborState))
            tree.add_edge(tuple(currentState), tuple(neighborState))
            priorityAdd(tree.nodes[tuple(neighborState)]['gapValue'] + tree.nodes[tuple(neighborState)]['costValue'], tuple(neighborState))
        
        # once we have explored this state, add it to the seen so we know not to see this again
        prioritySeen.append(tuple(currentState))
        nextState = currentState[:]

        # get the next item in the priorityQ that we have not yet explored
        while tuple(nextState) in prioritySeen and not doneState:
            nextState = priorityGet()
        
        currentState = list(nextState)
    
    # since there is only 1 path from the start to the goal state, we only get that answer
    path = nx.shortest_path(tree, source=tuple(startState), target=tuple(goalState))
    print("Found solution using " + str(len(path) - 1)  + " flips. Below is the order of the flips.")
    for state in path:
        print(state)

# same as AStar() but removes any use of gapHeuristic
def UCS(arr):
    startState = arr[:]
    currentState = arr[:]
    tree.add_node(tuple(currentState), costValue=0)
    doneState = False

    while not doneState:
        for i in range(len(currentState) - 1):
            # make a copy of current State and flip it at the current spot to find all possible moves from here
            neighborState = currentState[:]
            neighborState = flip(neighborState, i)

            if neighborState == goalState:
                tree.add_node(tuple(neighborState), costValue=costFunction(currentState))
                tree.add_edge(tuple(currentState), tuple(neighborState))
                doneState = True
                break

            # if the current neighbor is the neighbor we just came from, ignore it and continue
            if tuple(neighborState) in tree.nodes() and tree.has_edge(tuple(neighborState), tuple(currentState)):
                continue

            # removes the node if the priority before is larger than the current since we readd them in afterwards and will only allow the shortest path to exist
            if tuple(neighborState) in tree.nodes() and prioritiyValues[tuple(neighborState)] > tree.nodes[tuple(neighborState)]['costValue']:
                tree.remove_node(tuple(neighborState))
            
            # if the priority is the same or worse than whatever we have, just ignore it to avoid adding the same node
            elif tuple(neighborState) in tree.nodes() and prioritiyValues[tuple(neighborState)] <= tree.nodes[tuple(neighborState)]['costValue']:
                continue
            
            # once everything else has passed, we add the current neighbor into the graph with an edge from the current state and add a priority for the neighbor so we know when we should explore it
            tree.add_node(tuple(neighborState), costValue=costFunction(currentState))
            tree.add_edge(tuple(currentState), tuple(neighborState))
            priorityAdd(tree.nodes[tuple(neighborState)]['costValue'], tuple(neighborState))
        
        # once we have explored this state, add it to the seen so we know not to see this again
        prioritySeen.append(tuple(currentState))
        nextState = currentState[:]

        # get the next item in the priorityQ that we have not yet explored
        while tuple(nextState) in prioritySeen and not doneState:
            nextState = priorityGet()
        
        currentState = list(nextState)
    
    # since there is only 1 path from the start to the goal state, we only get that answer
    path = nx.shortest_path(tree, source=tuple(startState), target=tuple(goalState))
    print("Found solution using " + str(len(path) - 1)  + " flips. Below is the order of the flips.")
    for state in path:
        print(state)

# used to flip array at given flipPoint
def flip(arr, flipPoint):
    result = arr[:]
    flipSection = result[flipPoint:len(result)]
    flipSection.reverse()

    result[flipPoint:len(result)] = flipSection

    return result

# heuristic function based on Malte Helmert's Landmark Heuristics for the Pancake Problem
def gapHeuristic(arr):
    gapSet = []
    for pancake in arr:
        if arr.index(pancake) + 1 < len(arr) and abs(pancake - arr[arr.index(pancake) + 1]) > 1:
            gapSet.append(pancake)
    
    return len(gapSet)

# how many flips it took to get to this state
def costFunction(fromArr):
    # get the cost of the previous node
    fromArrCostValue = tree.nodes[tuple(fromArr)]['costValue']
    return fromArrCostValue + 1


# Implemented using StackOverFlow
def priorityAdd(priority, state):
    heapq.heappush(prioritiyQ, (priority, state))
    # also adds to another dict to get the priority for comparison later
    prioritiyValues[state] = priority

def priorityGet():
    priority, state = heapq.heappop(prioritiyQ)
    return state

# used to make priority queue
prioritiyQ = []

# used to keep track of nodes we visited to avoid repeats
prioritySeen = []

# used to track the best priority values
prioritiyValues = {}

# used to create a graph to make traversal easier
tree = nx.DiGraph()



print("\n=============================================\nWelcome to Harmeet's Pancake Flipping Factory!\n=============================================\n")
userChoiceAlgorithm = input("Would you like to utilize A* or UCS?\nEnter 1 for A* or Enter 2 for UCS: ")
userChoiceProblemSize = int(input("Please enter a number of pancakes you would like to see solved (INTEGER GREATER THAN 1): "))

# based on user input randomly generate a problem stack
problem = random.sample(range(1,userChoiceProblemSize + 1), userChoiceProblemSize)
print("\n=============================================\nThe generated problem stack is " + str(problem) + "\n=============================================\n")

# create goal state so we know what we want to look for
goalState = problem[:]
goalState.sort(reverse=True)

if userChoiceAlgorithm == "1":
    AStar(problem)
if userChoiceAlgorithm == "2":
    UCS(problem)