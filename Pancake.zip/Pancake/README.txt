Author: Harmeet Singh
Last Update Date: 2/27/2025

What is main.py...
    main.py is the file to run to solve a Pancake Problem. It has many functions within it to help it solve any size problem. To start, run the file.

How to use main.py...
    The program will ask you first if you want to use A* or UCS for the search method. Enter just the number 1 to enable A*. Enter just the number 2 to enable UCS.
    Then it will ask you for an integer greater than 1 for the size of the problem. It will then generate a random pancake stack and will show you where it is starting.
    It will then run through whichever algorithm was chosen with the generated problem set and try to find a solution.

NetworkX...
    I used networkx to make the graph. This allows you to add nodes and edges with weights or without and construct graphs easily. 
    My usage of it was adding the current state with a backward cost and forward cost as its attributes. Then to check neighbors, simply add them in with the same parameters.
    However this would lead to a lot of duplicates and would also lead to cycles which I wanted to avoid. To solve this I checked if the neighbor was already connected to the current state, 
    this basically meant that we just came from that state to this current one so there is no reason to check it. Then the other case is if the same state appears somewhere else in the graph.
    For this case, I checked the priority of the neighbor as stored already. if it was worse than what I would get from the current state, I removed the node which would then remove the edge 
    and then just added the node as normal afterwards so that the only path to this node would be the best path. If the priority stored was better than the current calculation we just skip.
    Now this also leads to an issue of having duplicates in the priority queue. To deal with this I had an array that would track which nodes had been visited already and checked. This way
    we just skip duplicate values later down the line if the priority comes up.

Backward and Forward costs...
    The forward cost was calculated using the provided paper. I simply translated the formula into code. The backward cost was calculated by how many flips it had taken to reach that point by
    finding the previous node and seeing the number of flips it took to reach it.

Flip...
    I created a method to flip the stack by just reversing a subset of the array.

Priority Queue...
    I implemented a priority queue utilizing heapq and a StackOverFlow post.

AStar and UCS...
    Both algorithms are the exact same and most of what goes on is explained in NetworkX...
    However the difference is that AStar uses the gapHeuristic function along with normal cost to calculate the priority. UCS only uses cost function.

UCS Solution...
    UCS can be used for this problem. It results in a graph that is always exploring the earliest states and takes a long time as it will grow out very slowly ensuring it checks every single 
    neighbor before continuing to the next "layer" of states. It works for small stacks but after around 9 to 10 stacks it becomes very slow. A* goes very fast even up to 20 pancakes.
